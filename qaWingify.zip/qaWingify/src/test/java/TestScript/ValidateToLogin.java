package TestScript;

import Pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;

import java.util.*;


import org.testng.Assert;
import org.testng.annotations.Test;
import Pages.HomePage;
import Pages.LoginPage;

import java.util.ArrayList;


public class ValidateToLogin
        extends TestBase {


    //Validate that the user is able to Locate to the login page.
    @Test
    public void validateUrlPage_LandingPage() {
        LoginPage loginPage = LoginPage.getLoginPage();
        Assert.assertEquals(loginPage.getUrl(),
                "https://sakshingp.github.io/assignment/login.html",
                "Url doesn't match with the given url");
        Assert.assertEquals(loginPage.Acc_LoginPageText(), "Login Form",
                "User is not on Login page");
    }

    //Validate loginPage logo is Displaying or not
    @Test
    public void validateLoginPageLogoDisplay() {
        LoginPage loginPage = LoginPage.getLoginPage();
        Assert.assertTrue(loginPage.isLogoDisplayed(), "Logo not Displayed");
    }

    //Validate social_media login icons are Displaying or not
    @Test
    public void validateSocialMediaIcons() {
        LoginPage loginPage = LoginPage.getLoginPage();


    }

    //Validate username & Password icons are Displaying or not
    @Test
    public void validateUsername_PasswordIcon() {
        LoginPage loginPage = LoginPage.getLoginPage();
        Assert.assertTrue(loginPage.isUsernameIconPresent());
        Assert.assertTrue(loginPage.isPasswordIconPresent());

    }

    //Validate username & Password field is Displayed
    @Test
    public void validateUsernameAndPasswordTextBoxEnabled() {
        LoginPage loginPage = LoginPage.getLoginPage();
        Assert.assertTrue(loginPage.isUsernameTextBoxEnabled(),
                "UserName section is not able");
        Assert.assertTrue(loginPage.isPasswordTextBoxEnabled(),
                "Password section is not able");

    }

    // Validate Placeholder is Displayed
    @Test
    public void validatePlaceholderIsDisplay() {
        LoginPage loginPage = LoginPage.getLoginPage();
        Assert.assertEquals(loginPage.getUsernamePlaceholder(), "Enter your username",
                "Username placeholder doesn't match");
        Assert.assertEquals(loginPage.getPasswordPlaceholder(), "Enter your password",
                "Password placeholder doesn't match");
    }

    //Validate login without username and password
    @Test
    public void validateLoginWithoutUsernameAndPassword() {
        LoginPage loginPage = LoginPage.getLoginPage();
        loginPage.enter_Username_Password("", "");
        loginPage.clickOnLogin_button();
        Assert.assertEquals(loginPage.getMsgError(), "Both Username and Password must be present",
                "Wrong error message is showing");
    }

    //Validate login without password
    @Test
    public void validateLoginWithoutPassword() {
        LoginPage loginPage = LoginPage.getLoginPage();
        ArrayList<String> loginPageCred = loginPage.getCred();
        loginPage.enter_Username_Password(loginPageCred.get(0), "");
        loginPage.clickOnLogin_button();
        Assert.assertEquals(loginPage.getMsgError(), "Password must be present",
                "error message is showing");
    }

    //Validate login without username
    @Test
    public void validateLoginWithoutUsername() {
        LoginPage loginPage = LoginPage.getLoginPage();
        ArrayList<String> loginPageCred = loginPage.getCred();
        loginPage.enter_Username_Password("", loginPageCred.get(1));
        loginPage.clickOnLogin_button();
        Assert.assertEquals(loginPage.getMsgError(), "Username must be present",
                " error message is showing");
    }


    //Validate login with RememberMe Usability
    @Test
    public void validateRememberMeUses() {
        LoginPage loginPage = LoginPage.getLoginPage();
        ArrayList<String> loginPageCred = loginPage.getCred();
        loginPage.enter_Username_Password(loginPageCred.get(0), loginPageCred.get(1));
        Assert.assertTrue(loginPage.ClickOnRemem_btn(),
                "checkBox is not ticked remember this.");
        loginPage.clickOnLogin_button();
        loginPage.goBackInHistory();
        Assert.assertEquals(loginPage.getUsername(), loginPageCred.get(0),
                "Function is not working remember this.");
        loginPage.clickOnLogin_button();

    }


    //Validate login with username & password
    @Test
    public void validateLoginWithSpaces() {
        LoginPage loginPage = LoginPage.getLoginPage();
        loginPage.enter_Username_Password("    ", "    ");
        loginPage.clickOnLogin_button();
        Assert.assertNotEquals(loginPage.getUrl(), "https://sakshingp.github.io/assignment/login.html",
                "User has logged in homepage");
    }

    //Validate login with username & password
    @Test
    public void validateLogin() {
        LoginPage loginPage = LoginPage.getLoginPage();
        ArrayList<String> loginPageCred = loginPage.getCred();
        loginPage.enter_Username_Password(loginPageCred.get(0), loginPageCred.get(1));
        loginPage.clickOnLogin_button();
        Assert.assertEquals(loginPage.getUrl(), "https://sakshingp.github.io/assignment/home.html",
                "User is not landed on correct page");
    }

    //Validate Tab & Enter buttons are working in login form
    @Test
    public void validateTabAndEnterBtnWorking() {
        LoginPage loginPage = LoginPage.getLoginPage();
        loginPage.clickTabOnKeyboard();
        loginPage.clickTabOnKeyboard();
        ArrayList<String> loginPageCred = loginPage.getCred();
        loginPage.enterUsername(loginPageCred.get(0));
        loginPage.clickTabOnKeyboard();

        loginPage.enterPassword(loginPageCred.get(1));
        loginPage.clickTabOnKeyboard();
        loginPage.clickEnterKeyboard();
        Assert.assertEquals(loginPage.getUrl(), "https://sakshingp.github.io/assignment/login.html",
                "User is not redirect on correct page");
    }

    //Validate amount values given are sorted.
    @Test
    public void validateAmountListSorted() {
        validateLogin();
        HomePage homePage = HomePage.getHomePage();

        homePage.clickOnAmountHead();

        Assert.assertTrue(homePage.isAmountListSorted(), "AmountList is not sorted");
    }
}

