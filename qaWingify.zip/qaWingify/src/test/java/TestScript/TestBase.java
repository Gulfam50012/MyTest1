
package TestScript;//import java.util.*;

import Base.IntActions;
import Constant.ConstantPath;
import Utils.PropertyReading;
import Base.IntActions;
import Constant.ConstantPath;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import Utils.PropertyReading;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TestBase {

    //private DashboardPage dashboardPage;
    private static PropertyReading prop;

    @BeforeClass
    public void beforeClass() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy_HH_mm");
        System.setProperty("current.date.time", sdf.format(new Date()));
        prop = new PropertyReading(ConstantPath.CONFIG_PATH);

    }

    @BeforeMethod
    public void openBrowser() {
        IntActions.initializeBrowser(prop.getValue("url"),
                prop.getValue("browser"),
                Boolean.parseBoolean(prop.getValue("headless")));
    }


    @AfterMethod
    public void closeBrowser(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE)
            IntActions.closeBrowser();
    }
}
