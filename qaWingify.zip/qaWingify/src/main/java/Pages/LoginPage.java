
package Pages;//import java.util.*;

import Base.IntActions;
import Constant.ConstantPath;
import Utils.PropertyReading;
import Base.IntActions;
import Constant.ConstantPath;
import org.openqa.selenium.WebElement;
import Utils.PropertyReading;

import java.util.ArrayList;
import java.util.List;

public class LoginPage extends IntActions {

    private static LoginPage loginPage;
    private static PropertyReading loginPageProp, configProp;

    private LoginPage() {
        loginPageProp = new PropertyReading(ConstantPath.PROP_PATH + "LoginPage.properties");
        configProp = new PropertyReading(ConstantPath.CONFIG_PATH);
    }

    public static LoginPage getLoginPage() {
        if (loginPage == null)
            loginPage = new LoginPage();
        return loginPage;
    }

    public ArrayList<String> getCred() {
        ArrayList<String> credList = new ArrayList<>();
        credList.add(configProp.getValue("userName"));
        credList.add(configProp.getValue("passWord"));
        return credList;
    }

    public String Acc_LoginPageText() {
        return getElementText(getElement(loginPageProp.getValue("header"), true)).trim();
    }

    public String getUrl() {
        return getCurrentWebpageUrl();
    }

    public boolean isUsernameTextBoxEnabled() {
        return isFieldDisplayed(loginPageProp.getValue("usernameField"), true);
    }

    public boolean isPasswordTextBoxEnabled() {
        return isFieldDisplayed(loginPageProp.getValue("usernameField"), false);
    }

    public String getUsernamePlaceholder() {
        return getAttribute(getElement(loginPageProp.getValue("usernameField"), true), "placeholder");
    }

    public String getPasswordPlaceholder() {
        return getAttribute(getElement(loginPageProp.getValue("passwordField"), true), "placeholder");

    }

    public String getMsgError() {
        return getElementText(getElement(loginPageProp.getValue("errorText"), true));
    }

    public boolean ClickOnRemem_btn() {
        clickOnElement(loginPageProp.getValue("rememberMeBtn"), true);
        return isElementSelected(loginPageProp.getValue("rememberMeBtn"), true);
    }

    public String getUsername() {
        return getAttribute(getElement(loginPageProp.getValue("usernameField"), true), "value");
    }

    public void enter_Username_Password(String username, String password) {
        enterText(getElement(loginPageProp.getValue("usernameField"), true), username);
        enterText(getElement(loginPageProp.getValue("passwordField"), false), password);
    }

    public void enterUsername(String username) {
        enterText(getElement(loginPageProp.getValue("usernameField"), true), username);
    }

    public void enterPassword(String password) {
        enterText(getElement(loginPageProp.getValue("passwordField"), false), password);
    }

    public void clickOnLogin_button() {
        clickOnElement(loginPageProp.getValue("loginBtn"), true);
    }

    public boolean isLogoDisplayed() {
        return isElementDisplayed(loginPageProp.getValue("logoLocator"), true);
    }

    public boolean isUsernameIconPresent() {
        return isElementDisplayed(loginPageProp.getValue("usernameIcon"), true);
    }

    public boolean isPasswordIconPresent() {
        return isElementDisplayed(loginPageProp.getValue("passwordIcon"), true);
    }

    public List<Boolean> isSocialMediaIcons() {
        List<WebElement> iconList = getWebElementList(loginPageProp.getValue("iconsSocial"), true);
        List<Boolean> boolList = new ArrayList<>();
        for (WebElement element : iconList) {
            boolList.add(element.isDisplayed());
        }
        return boolList;
    }


    public void goBackInHistory() {
        navigateBack();
    }


}





