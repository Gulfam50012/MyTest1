
package Pages;//import java.util.*;

import Base.IntActions;
import Utils.PropertyReading;
import Constant.ConstantPath;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HomePage extends IntActions {

    private static HomePage homePage;
    private static PropertyReading homePageProp;

    private HomePage() {
        homePageProp = new PropertyReading(ConstantPath.PROP_PATH+"HomePage.properties");
    }

    public static HomePage getHomePage() {
        if (homePage == null)
            homePage = new HomePage();
        return homePage;
    }

    public void clickOnAmountHead() {
        clickOnElement(homePageProp.getValue("amountTable"), true);
    }

    public List<Double> getAmountList() {
        return getWebElementListInDouble(homePageProp.getValue("amountList"), true);
    }
    public boolean isAmountListSorted()
    {   List <Double> amountList = getAmountList();
        List<Double> tempList = new ArrayList<>(amountList);
        Collections.sort(tempList);
        return amountList.equals(tempList);
    }
}
