

package Base;//import java.util.*;

import com.google.common.io.Files;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class IntActions {
    private static WebDriver driver;
    private static WebDriverWait wait;
    private static Robot robot;

    public static void initializeBrowser(String url, String browser, boolean isHeadless) {
        switch (browser.toUpperCase()) {
            case "CHROME":
                ChromeOptions chromeOptions = new ChromeOptions();
                if (isHeadless) {
                    chromeOptions.setHeadless(true);
                }
                chromeOptions.addArguments("--remote-allow-origins=*");
                driver = new ChromeDriver(chromeOptions);
                break;
            case "FIREFOX":
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                if (isHeadless) {
                    firefoxOptions.setHeadless(true);
                    firefoxOptions.addArguments("--headless=new");
                }
                driver = new FirefoxDriver(firefoxOptions);
                break;
            case "EDGE":
                EdgeOptions edgeOptions = new EdgeOptions();
                if (isHeadless) {
                    edgeOptions.addArguments("--headless=new");
                }
                driver = new EdgeDriver(edgeOptions);
                break;
            default:
                System.out.println("Illegal Browser Name");
                break;
        }
        driver.manage().window().maximize();
        System.out.println(" Browser is Maximized. ");
        driver.get(url);
        System.out.println("The Web Url is : " + url);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public static void refreshTab() {
        driver.get(driver.getCurrentUrl());
    }

    public String getCurrentWebpageUrl() {
        return driver.getCurrentUrl();
    }

    public boolean isElementSelected(String locator, boolean isWaitRequired) {
        return getElement(locator, isWaitRequired).isSelected();
    }

    public boolean isElementDisplayed(String locator, boolean isWaitRequired) {
        return getElement(locator, isWaitRequired).isDisplayed();
    }

    public static void navigateBack() {
        driver.navigate().back();
    }

    protected boolean isFieldDisplayed(String locator, boolean isWaitRequired) {
        return getElement(locator, isWaitRequired).isEnabled();
    }

    protected void clickTabRobot() {
        try {
            robot = new Robot();
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
        } catch (AWTException e) {
            System.out.println(" Not able to click tab in Robot. ");

            throw new RuntimeException(e);
        }
    }

    protected void clickEnterRobot() {
        try {
            robot = new Robot();
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException e) {
            System.out.println(" Not able to click enter in Robot. ");
            throw new RuntimeException(e);
        }
    }

    protected List<WebElement> getWebElementList(String locator, boolean isWaitRequired) {
        String locatorType = getLocatorType(locator);
        String locatorValue = getLocatorValue(locator);
        System.out.println(" List of WebElement is getting. ");
        return driver.findElements(getByReference(locatorType, locatorValue));
    }


    protected List<Double> getWebElementListInDouble(String locator, boolean isWaitRequired) {
        List<WebElement> webElements = getWebElementList(locator, isWaitRequired);
        List<Double> elementListInteger = new ArrayList<>();
        for (WebElement element : webElements) {
            elementListInteger.add(Double.parseDouble(element.getText().
                    replace("+ ", "").
                    replace(" ", "").
                    replace(",", "").
                    replace("USD", "")));
        }
        System.out.println(" Web Element is getting in List. ");
        return elementListInteger;
    }

    protected WebElement getElement(String locator, boolean isWaitRequired) {
        WebElement element = null;
        String locatorType = getLocatorType(locator);
        String locatorValue = getLocatorValue(locator);
        if (isWaitRequired)
            element = wait.until(ExpectedConditions.visibilityOfElementLocated(getByReference(locatorType, locatorValue)));
        else
            element = driver.findElement(getByReference(locatorType, locatorValue));
        System.out.println(" Element is not getting. ");
        return element;
    }


    private String getLocatorType(String locator) {
        String locatorType = null;
        try {
            locatorType = locator.split("]:-")[0].substring(1);
        } catch (IndexOutOfBoundsException indexOutOfBoundsException) {

        }
        return locatorType;
    }

    private String getLocatorValue(String locator) {
        String locatorValue = null;
        try {
            locatorValue = locator.split("]:-")[1];
        } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            System.out.println("Locator Value is not getting. ");

        }
        return locatorValue;
    }

    private By getByReference(String locatorType, String locatorValue) {
        switch (locatorType.toUpperCase()) {
            case "XPATH":
                return By.xpath(locatorValue);
            case "ID":
                return By.id(locatorValue);
            case "CLASSNAME":
                return By.className(locatorValue);
            case "PARTIALLINK":
                return By.partialLinkText(locatorValue);
            case "LINKTEXT":
                return By.linkText(locatorValue);
            case "CSS":
                return By.cssSelector(locatorValue);
            case "TAGNAME":
                return By.tagName(locatorValue);
            case "NAME":
                return By.name(locatorValue);
            default:

        }
        return null;
    }

    protected String getElementText(WebElement element) {
        String text = element.getText();
        System.out.println("Employee will get the Text.");
        return text;
    }

    protected String getAttribute(WebElement element, String attribute) {
        System.out.println("Employee got the Attribute.");
        return element.getAttribute(attribute);
    }


    protected void clickOnElement(String locator, boolean isWaitRequired) {
        WebElement element = getElement(locator, isWaitRequired);
        if (isWaitRequired == true)
            element = wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
        System.out.println("Employee click on the text.");
    }

    protected void enterText(WebElement element, String textToBe) {
        if (element.isEnabled())
            element.sendKeys(textToBe);
        else element.sendKeys(textToBe);
        System.out.println("Employee enter the text.");

    }

    public void clickTabOnKeyboard() {
        clickTabRobot();
    }

    public void clickEnterKeyboard() {
        clickEnterRobot();
    }

    public void goBackInHistory() {
        navigateBack();
    }

    public static void closeBrowser() {
        driver.quit();
        System.out.println("Browser is Closed.");
    }
}
