package Constant;

public class ConstantPath {
    public static final String PROP_PATH = "src/main/resources/ConfigFiles/";
    public static final String CONFIG_PATH = "src/main/resources/ConfigFiles/Configuration.properties";
}
